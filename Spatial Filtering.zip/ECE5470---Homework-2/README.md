# Spatial Filtering Code
Resultant Images are in the Image Results folder
